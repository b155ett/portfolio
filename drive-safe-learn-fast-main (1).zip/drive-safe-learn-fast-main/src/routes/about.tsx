import { createFileRoute, Link } from "@tanstack/react-router";
import { Shield, Award, Heart, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/about")({
  component: AboutPage,
  head: () => ({
    meta: [
      { title: "About Steve Bissett - Grade A Driving Instructor | SBDT" },
      { name: "description", content: "Meet Steve Bissett, a fully accredited Grade A driving instructor based in East Harling, Norwich. 100% recommendation rate with 64+ reviews." },
      { property: "og:title", content: "About Steve Bissett - SBDT" },
      { property: "og:description", content: "Grade A driving instructor in East Harling & Norwich. Patient, professional instruction." },
    ],
  }),
});

function AboutPage() {
  return (
    <div className="flex flex-col">
      {/* Header */}
      <section className="bg-secondary py-16">
        <div className="mx-auto max-w-6xl px-4">
          <h1 className="mb-4 text-4xl font-bold text-secondary-foreground">About Steve</h1>
          <p className="max-w-2xl text-lg text-secondary-foreground/80">
            Fully accredited Grade A Driving Instructor, dedicated to helping
            learners become safe and confident drivers.
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-16">
        <div className="mx-auto max-w-6xl px-4">
          <div className="grid gap-12 lg:grid-cols-2">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Your Local Driving Instructor</h2>
              <p className="text-muted-foreground">
                Based in East Harling and covering Norwich and the surrounding
                areas (NR16), Steve provides patient, friendly and professional
                driving instruction tailored to each learner's needs.
              </p>
              <p className="text-muted-foreground">
                As a fully accredited Grade A instructor, Steve is committed to
                the highest standards of teaching. Whether you're a complete
                beginner, need to build confidence, or want to polish your skills
                before your test, you'll receive expert guidance every step of
                the way.
              </p>
              <p className="text-muted-foreground">
                With a 100% recommendation rate from over 64 reviews, Steve's
                calm and encouraging approach has helped countless learners pass
                their driving test and become safe, independent drivers.
              </p>
              <Button asChild>
                <Link to="/contact">Book a Lesson</Link>
              </Button>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              {[
                { icon: Shield, title: "Grade A Accredited", desc: "Highest DVSA grading for driving instructors" },
                { icon: Award, title: "100% Recommended", desc: "64+ five-star reviews from happy learners" },
                { icon: Heart, title: "Patient & Friendly", desc: "Calm, supportive lessons with no pressure" },
                { icon: Users, title: "All Abilities", desc: "Beginners to experienced — everyone welcome" },
              ].map((item) => (
                <Card key={item.title}>
                  <CardContent className="p-5">
                    <item.icon className="mb-3 h-8 w-8 text-primary" />
                    <h3 className="mb-1 font-semibold">{item.title}</h3>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
