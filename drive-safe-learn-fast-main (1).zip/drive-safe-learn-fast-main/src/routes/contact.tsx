import { createFileRoute } from "@tanstack/react-router";
import { Phone, Mail, MapPin, Facebook, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({
    meta: [
      { title: "Contact Steve Bissett Driver Training | Book Driving Lessons" },
      { name: "description", content: "Get in touch with Steve Bissett Driver Training to book your driving lessons. Call 07881 553168 or email stevenbissett00@gmail.com." },
      { property: "og:title", content: "Contact SBDT - Book Driving Lessons" },
      { property: "og:description", content: "Book driving lessons in East Harling & Norwich. Call 07881 553168." },
    ],
  }),
});

function ContactPage() {
  return (
    <div className="flex flex-col">
      <section className="bg-secondary py-16">
        <div className="mx-auto max-w-6xl px-4">
          <h1 className="mb-4 text-4xl font-bold text-secondary-foreground">Get in Touch</h1>
          <p className="max-w-2xl text-lg text-secondary-foreground/80">
            Ready to start your driving journey? Contact Steve to book your
            first lesson or ask any questions.
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto max-w-6xl px-4">
          <div className="grid gap-8 md:grid-cols-2">
            {/* Contact details */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Contact Details</h2>

              <div className="space-y-4">
                <Card>
                  <CardContent className="flex items-start gap-4 p-5">
                    <Phone className="mt-0.5 h-6 w-6 text-primary" />
                    <div>
                      <h3 className="font-semibold">Phone</h3>
                      <a
                        href="tel:+447881553168"
                        className="text-muted-foreground hover:text-primary"
                      >
                        07881 553168
                      </a>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="flex items-start gap-4 p-5">
                    <Mail className="mt-0.5 h-6 w-6 text-primary" />
                    <div>
                      <h3 className="font-semibold">Email</h3>
                      <a
                        href="mailto:stevenbissett00@gmail.com"
                        className="text-muted-foreground hover:text-primary"
                      >
                        stevenbissett00@gmail.com
                      </a>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="flex items-start gap-4 p-5">
                    <MapPin className="mt-0.5 h-6 w-6 text-primary" />
                    <div>
                      <h3 className="font-semibold">Location</h3>
                      <p className="text-muted-foreground">
                        Based in East Harling, Norwich, NR16
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Covering Norwich and surrounding areas
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="flex items-start gap-4 p-5">
                    <Facebook className="mt-0.5 h-6 w-6 text-primary" />
                    <div>
                      <h3 className="font-semibold">Facebook</h3>
                      <a
                        href="https://facebook.com/bissettnxtgen"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-muted-foreground hover:text-primary"
                      >
                        Steve Bissett Driver Training - SBDT
                      </a>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="flex items-start gap-4 p-5">
                    <Clock className="mt-0.5 h-6 w-6 text-primary" />
                    <div>
                      <h3 className="font-semibold">Availability</h3>
                      <p className="text-muted-foreground">
                        Lessons available throughout the week
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Call or message to check availability
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* CTA side */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Book Your First Lesson</h2>
              <p className="text-muted-foreground">
                The quickest way to get started is to give Steve a call. He'll
                discuss your needs, answer any questions, and arrange your first
                lesson at a time that suits you.
              </p>

              <div className="rounded-xl bg-muted p-6">
                <h3 className="mb-4 text-lg font-semibold">Why choose SBDT?</h3>
                <ul className="space-y-3 text-sm text-muted-foreground">
                  {[
                    "Fully accredited Grade A instructor",
                    "100% recommendation rate (64+ reviews)",
                    "Patient and friendly teaching style",
                    "Flexible lesson times",
                    "Local to East Harling and Norwich area",
                    "Lessons tailored to your ability",
                  ].map((point) => (
                    <li key={point} className="flex items-start gap-2">
                      <span className="mt-1.5 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-primary" />
                      {point}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex flex-col gap-3 sm:flex-row">
                <Button size="lg" className="flex-1" asChild>
                  <a href="tel:+447881553168">
                    <Phone className="mr-2 h-4 w-4" />
                    Call 07881 553168
                  </a>
                </Button>
                <Button size="lg" variant="outline" className="flex-1" asChild>
                  <a href="mailto:stevenbissett00@gmail.com">
                    <Mail className="mr-2 h-4 w-4" />
                    Send Email
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
