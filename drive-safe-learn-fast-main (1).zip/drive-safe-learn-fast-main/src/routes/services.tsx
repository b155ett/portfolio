import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock, Zap, GraduationCap, RefreshCw, Car, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/services")({
  component: ServicesPage,
  head: () => ({
    meta: [
      { title: "Driving Lesson Services - Steve Bissett Driver Training | SBDT" },
      { name: "description", content: "Weekly driving lessons, intensive courses, Pass Plus, and refresher lessons in East Harling and Norwich. Book with SBDT today." },
      { property: "og:title", content: "Services - SBDT Driving Lessons" },
      { property: "og:description", content: "Weekly lessons, intensive courses, Pass Plus & more in East Harling & Norwich." },
    ],
  }),
});

const services = [
  {
    icon: Clock,
    title: "Weekly Lessons",
    description:
      "Regular 1 or 2 hour lessons that fit around your schedule. Perfect for building skills at a steady pace with consistent progress between lessons.",
    features: ["Flexible scheduling", "1 or 2 hour sessions", "Structured learning plan", "Progress tracking"],
  },
  {
    icon: Zap,
    title: "Intensive Courses",
    description:
      "Fast-track your way to passing with an intensive course. Ideal if you have a test coming up or want to learn in a shorter time frame.",
    features: ["Fast-track learning", "Concentrated practice", "Test preparation", "Flexible duration"],
  },
  {
    icon: GraduationCap,
    title: "Pass Plus",
    description:
      "Already passed your test? Pass Plus helps you gain confidence on motorways, in the dark, in bad weather and more. May reduce insurance costs.",
    features: ["Post-test confidence", "Motorway driving", "Night driving", "Insurance discounts"],
  },
  {
    icon: RefreshCw,
    title: "Refresher Lessons",
    description:
      "Haven't driven in a while? Refresher lessons help you regain confidence and update your skills in a relaxed, supportive environment.",
    features: ["Confidence building", "Skill assessment", "Flexible sessions", "No pressure approach"],
  },
  {
    icon: Car,
    title: "Test Preparation",
    description:
      "Focused lessons to prepare you specifically for your practical driving test. Includes mock tests and covering test routes.",
    features: ["Mock driving tests", "Test route practice", "Manoeuvre perfection", "Nerves management"],
  },
];

function ServicesPage() {
  return (
    <div className="flex flex-col">
      <section className="bg-secondary py-16">
        <div className="mx-auto max-w-6xl px-4">
          <h1 className="mb-4 text-4xl font-bold text-secondary-foreground">Services</h1>
          <p className="max-w-2xl text-lg text-secondary-foreground/80">
            Professional driving instruction tailored to your needs, from first
            lesson to test day and beyond.
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto max-w-6xl px-4">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {services.map((service) => (
              <Card key={service.title} className="flex flex-col transition-shadow hover:shadow-lg">
                <CardHeader>
                  <service.icon className="mb-2 h-10 w-10 text-primary" />
                  <CardTitle>{service.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-1 flex-col">
                  <p className="mb-4 text-sm text-muted-foreground">{service.description}</p>
                  <ul className="mt-auto space-y-1">
                    {service.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 text-sm">
                        <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                        {f}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-12 rounded-xl bg-primary p-8 text-center md:p-12">
            <h2 className="mb-3 text-2xl font-bold text-primary-foreground">
              Not sure which option is right for you?
            </h2>
            <p className="mx-auto mb-6 max-w-xl text-primary-foreground/80">
              Give Steve a call to discuss your needs and find the best lesson
              plan for you.
            </p>
            <Button variant="secondary" size="lg" asChild>
              <a href="tel:+447881553168">
                <Phone className="mr-2 h-4 w-4" />
                Call 07881 553168
              </a>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
