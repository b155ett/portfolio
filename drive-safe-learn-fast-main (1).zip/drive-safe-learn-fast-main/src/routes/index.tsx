import { createFileRoute, Link } from "@tanstack/react-router";
import { Phone, Star, Shield, Clock, MapPin, CheckCircle, Quote } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import trainingCar from "@/assets/training-car.jpg";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Steve Bissett Driver Training - Driving Lessons in East Harling & Norwich" },
      { name: "description", content: "Fully accredited Grade A driving instructor based in East Harling, Norwich. 100% recommendation rate from 64+ reviews. Book your driving lessons today!" },
      { property: "og:title", content: "Steve Bissett Driver Training - SBDT" },
      { property: "og:description", content: "Grade A driving instructor in East Harling & Norwich. 100% recommended. Book your lessons today!" },
      { property: "og:type", content: "website" },
    ],
  }),
});

function Index() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="relative flex min-h-[70vh] items-center overflow-hidden">
        <img
          src={trainingCar}
          alt="S Bissett Driver Training - VW Polo training car"
          className="absolute inset-0 h-full w-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-secondary/90 via-secondary/70 to-secondary/40" />
        <div className="relative z-10 mx-auto max-w-6xl px-4 py-20">
          <div className="max-w-xl">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary/20 px-4 py-1.5 text-sm font-medium text-primary-foreground">
              <Shield className="h-4 w-4" />
              Grade A Accredited Instructor
            </div>
            <h1 className="mb-4 text-4xl font-bold leading-tight tracking-tight text-secondary-foreground md:text-5xl lg:text-6xl">
              Learn to Drive with{" "}
              <span className="text-primary">Confidence</span>
            </h1>
            <p className="mb-8 text-lg text-secondary-foreground/80">
              Professional driving lessons in East Harling, Norwich and
              surrounding areas. Patient, friendly instruction tailored to you.
            </p>
            <div className="flex flex-col gap-3 sm:flex-row">
              <Button size="lg" asChild>
                <a href="tel:+447881553168">
                  <Phone className="mr-2 h-4 w-4" />
                  07881 553168
                </a>
              </Button>
              <Button size="lg" variant="secondary" asChild>
                <Link to="/contact">Get in Touch</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Trust bar */}
      <section className="border-b bg-card py-6">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-center gap-8 px-4 text-center">
          <div className="flex items-center gap-2">
            <Star className="h-5 w-5 text-primary" />
            <span className="text-sm font-semibold">100% Recommended</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-primary" />
            <span className="text-sm font-semibold">64+ Five-Star Reviews</span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            <span className="text-sm font-semibold">DVSA Approved</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" />
            <span className="text-sm font-semibold">East Harling & Norwich</span>
          </div>
        </div>
      </section>

      {/* Services overview */}
      <section className="py-16 md:py-24">
        <div className="mx-auto max-w-6xl px-4">
          <div className="mb-12 text-center">
            <h2 className="mb-3 text-3xl font-bold">Driving Lessons to Suit You</h2>
            <p className="mx-auto max-w-2xl text-muted-foreground">
              Whether you're a complete beginner or need a refresher, Steve
              offers patient, professional lessons to get you on the road safely.
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: Clock,
                title: "Weekly Lessons",
                description:
                  "Regular 1 or 2 hour lessons that fit around your schedule. Build skills gradually at a pace that suits you.",
              },
              {
                icon: Shield,
                title: "Intensive Courses",
                description:
                  "Fast-track your learning with intensive driving courses. Ideal if you need to pass quickly.",
              },
              {
                icon: Star,
                title: "Pass Plus",
                description:
                  "Already passed? Develop your skills further with Pass Plus and potentially reduce your insurance premiums.",
              },
            ].map((service) => (
              <Card key={service.title} className="transition-shadow hover:shadow-lg">
                <CardContent className="p-6">
                  <service.icon className="mb-4 h-10 w-10 text-primary" />
                  <h3 className="mb-2 text-lg font-semibold">{service.title}</h3>
                  <p className="text-sm text-muted-foreground">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-10 text-center">
            <Button variant="outline" size="lg" asChild>
              <Link to="/services">View All Services</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-muted py-16 md:py-24">
        <div className="mx-auto max-w-6xl px-4">
          <div className="mb-12 text-center">
            <h2 className="mb-3 text-3xl font-bold">What Our Learners Say</h2>
            <p className="mx-auto max-w-2xl text-muted-foreground">
              100% recommendation rate from over 64 reviews. Here's what some of
              our successful learners have to say.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            {[
              {
                name: "Sophie T.",
                quote:
                  "Steve was incredibly patient and really helped me build my confidence. I passed first time thanks to his brilliant teaching! Couldn't recommend him enough.",
                detail: "Passed first time",
              },
              {
                name: "Jake M.",
                quote:
                  "I was so nervous when I started but Steve made every lesson relaxed and fun. His calm approach made all the difference. Buzzing to have passed!",
                detail: "Passed first time",
              },
              {
                name: "Emily R.",
                quote:
                  "After a bad experience with another instructor, Steve completely turned things around. Professional, encouraging and genuinely cares about your progress.",
                detail: "Passed with only 2 minors",
              },
            ].map((testimonial) => (
              <Card key={testimonial.name} className="transition-shadow hover:shadow-lg">
                <CardContent className="p-6">
                  <Quote className="mb-3 h-6 w-6 text-primary" />
                  <p className="mb-4 text-sm text-muted-foreground italic">
                    "{testimonial.quote}"
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">{testimonial.name}</span>
                    <span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
                      {testimonial.detail}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-primary py-16">
        <div className="mx-auto max-w-6xl px-4 text-center">
          <h2 className="mb-4 text-3xl font-bold text-primary-foreground">
            Ready to Start Your Journey?
          </h2>
          <p className="mx-auto mb-8 max-w-xl text-primary-foreground/80">
            Get in touch today to book your first lesson. Patient, friendly
            instruction from a fully accredited Grade A instructor.
          </p>
          <div className="flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button
              size="lg"
              variant="secondary"
              asChild
            >
              <a href="tel:+447881553168">
                <Phone className="mr-2 h-4 w-4" />
                Call 07881 553168
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10"
              asChild
            >
              <Link to="/contact">Send a Message</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
