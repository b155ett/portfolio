import { Link } from "@tanstack/react-router";
import { Phone, Mail, MapPin, Facebook } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t bg-secondary text-secondary-foreground">
      <div className="mx-auto max-w-6xl px-4 py-12">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <h3 className="mb-3 text-lg font-bold text-primary">SBDT</h3>
            <p className="text-sm opacity-80">
              Fully accredited Grade A Driving Instructor. Based in East Harling
              and covering surrounding areas.
            </p>
          </div>

          <div>
            <h4 className="mb-3 font-semibold">Quick Links</h4>
            <ul className="space-y-2 text-sm opacity-80">
              <li><Link to="/" className="hover:text-primary">Home</Link></li>
              <li><Link to="/about" className="hover:text-primary">About</Link></li>
              <li><Link to="/services" className="hover:text-primary">Services</Link></li>
              <li><Link to="/contact" className="hover:text-primary">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-3 font-semibold">Contact</h4>
            <ul className="space-y-2 text-sm opacity-80">
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-primary" />
                <a href="tel:+447881553168" className="hover:text-primary">07881 553168</a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-primary" />
                <a href="mailto:stevenbissett00@gmail.com" className="hover:text-primary">
                  stevenbissett00@gmail.com
                </a>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-primary" />
                <span>East Harling, Norwich, NR16</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="mb-3 font-semibold">Follow Us</h4>
            <a
              href="https://facebook.com/bissettnxtgen"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-sm opacity-80 hover:text-primary"
            >
              <Facebook className="h-5 w-5" />
              Facebook
            </a>
          </div>
        </div>

        <div className="mt-8 border-t border-secondary-foreground/20 pt-6 text-center text-xs opacity-60">
          © {new Date().getFullYear()} Steve Bissett Driver Training. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
